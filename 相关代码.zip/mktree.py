#该代码与muscle、要进行建树的序列blasta文件放入同一文件夹使用
#在进行建树前在该文件夹外事先准备一个存放treefile文件的文件夹并更改代码中的路径
import os
L=[]#用于存储文件名
def file_name(file_dir):#括号内为要获取文件名称的目录路径
    for root,dirs,files in os.walk(file_dir):
        #print(root)#当前目录路径
        #print(dirs)#当前路径下所有子目录
        #print(files)#当前路径下所有非目录子文件
        for file in files:
            if os.path.splitext(file)[1]=='.fasta':#提取.fasta文件
                L.append(os.path.splitext(file)[0])#仅存入文件名，不存入扩展名
        #for file in files:
            #if os.path.splitext(file)[1]=='.phy':#可以将文件名拆分成名字和扩展名
                #L.append(os.path.join(file))
#建树文件所在文件夹（需改）
file_name('G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\tree')#运行一次获取所在目录文件名
print(L)#用于检测文件获取结果
for i in L:
    cmd1='muscle -in '+i+'.fasta'+' -out '+i+'.phy'
    #语句：muscle -in 输入文件 -out 输出文件
    result1=os.popen(cmd1)#运行cmd指令进行序列比对
    print(cmd1)
    print(result1.read())#控制
for i in L:
    cmd2='iqtree -s '+i+'.phy'+' -m MFP -bb 1000 -bnni -nt AUTO -redo'#构建指令语句,'-b 100'为测试用，可根据实际情况更改参数（注：已更改为-bb 1000） 
    #语句：iqtree -s 文件.phy -m MFP -bb 1000 -bnni -nt AUTO -redo
    result2=os.popen(cmd2)#运行cmd指令进行建树
    print(cmd2)#检测语句是否正常
    print(result2.read())#打印建树过程中的内容用来提示建树完成
for i in L:
#treefile文件转移路径（需改）
    cmd3='move '+i+'.phy.treefile G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\treefile'#将建好的treefile文件移入事先创建的文件夹中
    #语句：move 要移动的路径/文件名 要移入的文件夹名
    result3=os.popen(cmd3)#运行cmd指令移动文件
    print(cmd3)#检测语句是否正常
