library("ggplot2")
#library("ggpubr")
setwd("/home/yanghuatie/Kaks/data/C_sativa/plot/")#change
library("extrafont")
font_import()
loadfonts()
lt <- read.table("/home/yanghuatie/Kaks/data/C_sativa/list.txt", header = F)#change
for (i in lt[,1]){
	title<-paste("/home/yanghuatie/Kaks/data/C_sativa/result/",i,sep="")#change
	boxdata <- read.table(title, header = T)
	df<-data.frame(kaks=c(boxdata[,2]),gene=c(rep(i,length(boxdata[,2]))))
	ggplot(df,aes(x=gene,y=kaks))+geom_boxplot(color="blue")+geom_point(color="red")+labs(x="",y="")+theme_classic()
	ggplot(df,aes(x=gene,y=kaks))+geom_boxplot(color="blue")+geom_point(color="red")+labs(x="",y="")+theme_minimal()
	myfilename <- paste(i, ".pdf", sep = "")
	ggsave(filename = myfilename)
	myfilename <- paste(i, ".png", sep = "")
	ggsave(filename = myfilename)
}
