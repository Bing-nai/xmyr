#!/bin/bash
mkdir ./result/0kb
for z in `find ./result/ -size 0`
do
##	x=`basename $z .txt`	
	mv $z ./result/0kb
done
