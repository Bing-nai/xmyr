from re import *
import os
L=[]
#获取所有序列文件文件名
def file_name(file_dir):
    for root,dirs,files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1]=='.fasta':
                L.append(os.path.splitext(file)[0])
#所有序列所在文件夹（需改）
file_name('C:\\Users\\戴尔\\Desktop\\红豆\\tree\\')
print(L)
count1=0
#通过改名对能建树的文件消除'_'标记，不能建树的文件保留标记
for n in L:
#所有序列所在文件夹（需改）
    os.rename('C:\\Users\\戴尔\\Desktop\\红豆\\tree\\'+n+'.fasta','C:\\Users\\戴尔\\Desktop\\红豆\\tree\\'+n[:-1]+'.fasta')
    count1=0