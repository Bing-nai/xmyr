#!/bin/bash
ls ./result > list.txt
mkdir plot
a=`pwd`
for z in `ls ./result/`
do
	sort  -r -u ./result/$z -o ./result/$z
done
/usr/bin/Rscript $a/../plot.R
