#!/bin/bash
mkdir re_meme
cd re_meme
for file_name in `ls ../2/`
do
	a=`basename $file_name .fasta`
	mkdir ./$a
	cd ./$a
	meme ../../2/$file_name -protein -oc result -nostatus -time 1800000 -mod zoops -nmotifs 1000 -minw 6 -maxw 13 -objfun classic -markov_order 0
	cd ..
done

