import os
V_in_A = open("D:/My_File/study/创新项目/double_blast/AT_VR/V_in_A.blast","r")
A_in_V = open("D:/My_File/study/创新项目/double_blast/AT_VR/A_in_V.blast","r")
AT_file = open("D:/My_File/study/创新项目/Arabidopsis_thaliana/result/flowering_longest_pro_modify.fasta","r")
VR_file = open("D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/result/pro_modify.fasta","r")
V_in_A_list = []
A_in_V_list = []
intersection = []
AT = []
VR = []
num_AT = {}
AT_list = []
cannot_build_tree = []
build_tree_id_list = []
AT_seq_dir = {}
VR_seq_dir = {}
#将序列文件转化为字典
for eachline in AT_file:
    eachline = eachline.strip('\n')
    if eachline[0] == '>':
        key = eachline
    else:
        AT_seq_dir[key] = eachline
        key = None
for eachline in VR_file:
    eachline = eachline.strip('\n')
    if eachline[0] == '>':
        key = eachline
    else:
        VR_seq_dir[key] = eachline
        key = None
#处理blast文件
# 1、将blast文件逐条存入二维数组
for eachline in V_in_A:
    eachline = eachline.strip('\n')
    message = eachline.split(' ')
    if message[2] > 50:
        V_in_A_list.append(message)
for eachline in A_in_V:
    eachline = eachline.strip('\n')
    message = eachline.split(' ')
    if message[2] > 50:
        A_in_V_list.append(message)
# 2、去重并求交
for m in range(len(V_in_A_list)):
    for n in range(len(A_in_V_list)):
        for k in range(len(intersection)):
            if A_in_V_list[n][0] == intersection[k][0] and A_in_V_list[n][1] == intersection[k][1]:
                j = 1
                break
        if not j and V_in_A_list[m][0] == A_in_V_list[n][1] and V_in_A_list[m][1] == A_in_V_list[n][0]:
            intersection.append(A_in_V_list[0:1])
            AT.append(A_in_V_list[0])
            VR.append(A_in_V_list[1])
#统计豆科植物基因与每个拟南芥基因匹配个数 
for key in AT:
    num_AT[key] += 1
#创建建树的拟南芥基因ID列表文件
build_tree_AT_ID = open("D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/tree/file_name.txt","a+")
#分离能否建树的组,并将能建树的组的蛋白序列提取到相应fasta文件中，将相应文件加名放入file_name.txt文件中
for key in num_AT.keys():
    if num_AT[key] == 1 or num_AT[key] == 2:
        cannot_build_tree.append(key)
    else:
        build_tree_AT_ID.write(key)
        seq_file_dir = "D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/tree/" + key
        os.mkdir(seq_file_dir)
        seq_file = seq_file_dir + "/seq.fasta"
        build_tree_file = open(seq_file,"a")
        build_tree_file.write('>' + key)
        AT_key = '>' + key
        build_tree_file.write(AT_seq_dir[AT_key])
        for n in range(len(intersection)):
            if key == intersection[n][0]:
                build_tree_file.write('>' + intersection[n][1])
                VR_key = '>' + intersection[n][1]
                build_tree_file.write(VR_seq_dir[VR_key])
#将不能建树的组5个5个合并，并将每组蛋白序列提取到相应fasta文件中，将相应文件加名放入file_name.txt文件中
for n in range(len(cannot_build_tree)):
    if num <= 5:
        if cannot_build_tree[n] != cannot_build_tree[n - 1]:
            build_tree_id_list.append(cannot_build_tree[n])
            num += 1
        else:
            continue
    else:
        build_tree_file_name = '-'.join(build_tree_id_list)
        build_tree_AT_ID.write(build_tree_file_name)
        seq_file_dir = "D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/tree/" + build_tree_file_name
        os.mkdir(seq_file_dir)
        seq_file = seq_file_dir + "/seq.fasta"
        build_tree_file = open(seq_file,"a")
        for m in range(4):
            build_tree_file.write('>' + build_tree_id_list[m])
            AT_key = '>' + build_tree_id_list[m]
            build_tree_file.write(AT_seq_dir[AT_key])
            for s in range(len(intersection)):
                if build_tree_file_name[m] == intersection[s][0]:
                    build_tree_file.write('>' + intersection[s][1])
                    VR_key = '>' + intersection[s][1]
                    build_tree_file.write(VR_seq_dir[VR_key])
        num = 0
        build_tree_id_list = []
#建树
for eachline in build_tree_AT_ID:
    eachline = eachline.strip('\n')
    muscle = 'D:/MUSCLE/muscle -in D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/tree/' + eachline + '/seq.fasta -out D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/tree/' + eachline + '/ali.phy'
    #print(muscle)
    os.system(muscle)
    iqtree = 'iqtree -s D:/My_File/study/创新项目/Leguminosae_sp/Vigna_radiata/tree/' + eachline + '/ali.phy -m MFP -bb 1000 -bnni -nt AUTO -redo'
    #print(iqtree)
    os.system(iqtree)