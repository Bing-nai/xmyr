import os
L=[]
L1=[]
def file_name(file_dir):
    for root,dirs,files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1]=='.fasta':
                L.append(os.path.splitext(file)[0])
#fasta文件所在（需改）
file_name('G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\')
#print(L)
#获取带标记的文件名
for i in L:
    if '_' in i:
        L1.append(i)
print(L1)
#将带标记的文件转移
#分离文件的路径（需改）
for j in L1:
    cmd='move G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\'+j+'.fasta G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\不够建树'
    result=os.popen(cmd)
    print(cmd)
#合并文件
filename=[]
count=0
for k in range(len(L1)):
    if count==2:
        count=0
#被转移后不够建树文件所在（需改）
    file1=open('G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\不够建树\\'+L1[k]+'.fasta','r')
#合并后的新文件存储位置（需改）
    desktop_path = 'G:\\iqtree-1.6.12-Windows\\iqtree-1.6.12-Windows\\bin\\M_Ar_tree\\'
    if count==0:
        full_path = desktop_path + L1[k][:-1] + '.fasta'
    file2=open(full_path, 'a+')
    lennum=len(file1.readlines())
    file1.seek(0,0)
    for m in range(lennum):
        A=file1.readline()
        file2.writelines(A)
    count+=1
    file1.close()
    file2.close()

    

