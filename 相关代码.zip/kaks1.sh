#!/bin/bash
##sed -i '1,2d' ./1/*.fasta
for file_name in `ls ./2`
do
	a=`basename $file_name .fasta`
	a1=".fasta"
	a2="./2/"
	a3="./3/"
	a4="./1/"
	a5="_"
	a6="./4/"
	a7="cds"
	a8="pep"
	a9="aln"
	a10="./5/"
	a11="/"
	c="alig_"
	d1=$a2$a$a1
	d2=$a3$c$a$a1
	d3=$a4$a$a5$a1
	d4=$a6$a$a5$a7$a5$a8$a5$a9$a1
	d5=$a10$a
	d6=$d5$a11
	d7=../../$d4
	mafft --auto $d1 > $d2
	perl ../../pl_file/pal2nal.v14/pal2nal.pl $d2 $d3 -output fasta > $d4
##	sleep (20)
	mkdir $d5
	cd $d5
	csplit $d7 /\>/ -n2 -s {*} -f gene -b "%1d.fasta"
	rm gene0.fasta
	t=`ls -l |grep "^-" | wc -l`
	mkdir mix
	cd mix
##	for i in $(seq 1 $t)
##	do
##		j=$i
##		while [ ${j} -le ${t} ]
##		do
##			cat ../gene${i}.fasta ../gene${j}.fasta > ./gene${i}_${j}.fasta
##			j=$((10#${j}+1))
##		done
##		rm ./gene${i}_${i}.fasta
##	done
	for i in $(seq 1 $t)
	do
		cat ../gene1.fasta ../gene${i}.fasta > ./gene1_${i}.fasta
	done
	rm ./gene1_1.fasta
##	cd ../../..
	for i in *.fasta
	do
		echo $i
		perl ../../../../../axt/axt.pl $i
	done
	cd ../../..
	mkdir ./axtfile/$a
	mv ./5/$a/mix/*.axt ./axtfile/$a
	cd ./axtfile/$a
	for i in *.fasta.axt
	do
		echo $i
		../../../../kakscaluator2.0/KaKs_Calculator -i $i -o ${i%%.*}.kaks
	done
	cd ../..
	mkdir ./kaks/$a
	mv ./axtfile/$a/*.kaks ./kaks/$a
done
