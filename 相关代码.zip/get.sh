#!/bin/bash
mkdir result
for file_name in `ls ./2`
do
	a=`basename $file_name .fasta`
##	mkdir result/$a
	touch result/result_$a.txt
	for i in `ls ./kaks/$a`
	do
		awk -F '\t' '{print $1,$5}' ./kaks/$a/$i >> ./result/result_$a.txt
	done
done
