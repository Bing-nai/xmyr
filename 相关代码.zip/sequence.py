from re import *
import os
file1=open('f-V_r.fasta','r')
file2=open('test1.txt','r')
desktop_path = "C:\\Users\\戴尔\\Desktop\\绿豆\\tree\\"#提取的所有序列所在（需改）
count=0
C=[]
T=0
#提取所有序列,打入标记'_'
for i in range(3256): #分组文件行数（需改）   
    A=file2.readline()
    if C==A[0:11]:
        count+=1
    elif match(compile(r'\n'),A)!=None:
        count=0
        T=0
        continue
    if count==0:
        full_path = desktop_path +str(i)+ '_.fasta'
    file3=open(full_path,'a+')
    if match(compile(r'\n'),A)==None:
        A1=findall(compile(r'(.*?)\t'),A)[0]
        A2=findall(compile(r'\t(.*?)\n'),A)[0]
        print(A1)
        print(A2)
        file1.seek(T,0)
        for j in range(47308):#序列文件行数（需改）
            B1=file1.readline()
            if A1 in B1[:-1]:
                B2=file1.readline()
                print(B1[:-1])
                print(B2[:-1])
                T=file1.tell()
                file3.writelines(B1)
                file3.writelines(B2)
            elif A2 in B1[:-1]:
                B2=file1.readline()
                print(B1[:-1])
                print(B2[:-1])
                file3.writelines(B1)
                file3.writelines(B2)
    else:
        continue
    file3.close()
    C=A[0:11]
    print(count)
file1.close()
file2.close()
L=[]
#获取所有序列文件文件名
def file_name(file_dir):
    for root,dirs,files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1]=='.fasta':
                L.append(os.path.splitext(file)[0])
#所有序列所在文件夹（需改）
file_name('C:\\Users\\戴尔\\Desktop\\绿豆\\tree\\')
print(L)
count1=0
#通过改名对能建树的文件消除'_'标记，不能建树的文件保留标记
for n in L:
#所有序列所在文件夹（需改）
    file4=open('C:\\Users\\戴尔\\Desktop\\绿豆\\tree\\'+n+'.fasta','r')
    count1 = len(file4.readlines())
    file4.close()
    print(count1)
    if count1>=8:
#所有序列所在文件夹（需改）
        os.rename('C:\\Users\\戴尔\\Desktop\\绿豆\\tree\\'+n+'.fasta','C:\\Users\\戴尔\\Desktop\\绿豆\\tree\\'+n[:-1]+'.fasta')
        count1=0
        
